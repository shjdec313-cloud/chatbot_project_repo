# CASPER 2단계 제출물

## 파일 안내

- `CASPER_EDA_STATS_TFIDF.ipynb`: EDA·통계 검정·TF-IDF 코드와 실제 실행 출력
- `ANALYSIS_REPORT.md`: 같은 실행 결과로 생성한 제출용 보고서
- `figures/`: 보고서 그림 2개
- `results/`: 결측·길이·장별 통계, 검정, TF-IDF 키워드, 시연 결과, 검토 후보, 실행 환경
- `data/casper_manual_chunks.csv`: 분석 입력. 제공받은 CSV와 바이트 내용이 동일함
- `reference/previous_eda_results.json`: 기존 EDA 수치 대조용 참고 결과
- `execution_record.json`: 코드 셀 실행 횟수와 오류 여부 확인 기록

## 다시 실행하기

Python 3.12 환경에서 검증했다. ZIP을 풀고 VS Code에서 폴더 전체를 열면 Markdown 그림 경로가 유지된다.

PowerShell에서 해당 폴더로 이동한 뒤 다음 명령으로 별도 환경을 준비할 수 있다.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

VS Code의 Python·Jupyter 확장을 사용해 노트북을 열고, 오른쪽 위에서 `.venv`의 Python을 커널로 선택한 뒤 **Run All**을 누른다. 실행 작업 폴더는 노트북이 있는 폴더로 맞춘다. Python 3.12가 없다면 먼저 설치하거나 호환되는 Python 환경을 준비한다.

원본 CSV는 읽기만 한다. 다시 실행하면 `results/`, `figures/`, `ANALYSIS_REPORT.md`가 갱신된다. notebook 자체의 실행 출력은 실행 후 저장해야 반영된다.

## 해석 범위

이 자료는 한 매뉴얼의 분석이다. 목차 단위로 집계해도 원문 범위가 겹칠 수 있어 통계 검정은 탐색적 진단이다. TF-IDF 질문은 정답 라벨이 없는 동작 시연이며 검색 품질 평가셋이 아니다. 3단계 RAG 파이프라인·적재 로그와 4단계 검색 품질 평가는 별도로 완성해야 한다.
