param(
    [Parameter(Mandatory=$true)][string]$PersonalUser,
    [Parameter(Mandatory=$true)][string]$PersonalHost,
    [string]$PersonalPort = '5432'
)
$dumpPath = Join-Path $PSScriptRoot '..\data\new_personal_dump.sql'
$personalUri = "postgresql://${PersonalUser}@${PersonalHost}:${PersonalPort}/postgres?sslmode=require"
& 'C:\Program Files\PostgreSQL\18\bin\pg_dump.exe' `
  --data-only `
  --no-owner `
  --no-privileges `
  --table=public.manual_chunks `
  --table=public.manual_embeddings `
  --file=$dumpPath `
  --password `
  $personalUri
if ($LASTEXITCODE -ne 0) { throw 'Dump export failed.' }
