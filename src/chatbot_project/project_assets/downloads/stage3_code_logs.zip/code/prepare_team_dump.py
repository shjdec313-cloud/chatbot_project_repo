"""Replace only COPY destination names; do not change any stored data."""
import argparse,re
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source',type=Path);p.add_argument('destination',type=Path);a=p.parse_args()
if a.source.resolve()==a.destination.resolve():raise ValueError('Use a different output path')
text=a.source.read_text(encoding='utf-8')
for table in ['manual_chunks','manual_embeddings']:
    text,n=re.subn(r'^COPY public\.'+table+r' \(', 'COPY public.casper_'+table+' (',text,flags=re.M)
    if n!=1:raise ValueError('Expected exactly one COPY section for '+table)
a.destination.write_text(text,encoding='utf-8',newline='\n')
