# Restore the supplied team dump into the existing team tables.
# Set these from the team's Connect > Session pooler details.
# Password is entered at the prompt; do not put it in this file.
param(
    [Parameter(Mandatory=$true)][string]$TeamUser,
    [Parameter(Mandatory=$true)][string]$TeamHost,
    [string]$TeamPort = '5432',
    [string]$TeamDb = 'postgres'
)
$teamDumpPath = Join-Path $PSScriptRoot '..\data\casper_data_team.sql'
$teamUri = "postgresql://${TeamUser}@${TeamHost}:${TeamPort}/${TeamDb}?sslmode=require"
& 'C:\Program Files\PostgreSQL\18\bin\psql.exe' `
  --password `
  --set=ON_ERROR_STOP=1 `
  --single-transaction `
  --file=$teamDumpPath `
  $teamUri
if ($LASTEXITCODE -ne 0) { throw 'Restore failed; transaction was not committed.' }
