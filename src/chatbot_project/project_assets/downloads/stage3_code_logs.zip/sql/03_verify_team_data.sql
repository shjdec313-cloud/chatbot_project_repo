-- Read-only checks against the team database.
SELECT
 (SELECT count(*) FROM public.casper_manual_chunks) AS chunk_rows,
 (SELECT count(DISTINCT chunk_id) FROM public.casper_manual_chunks) AS unique_chunk_ids,
 (SELECT count(*) FROM public.casper_manual_embeddings) AS embedding_rows,
 (SELECT count(DISTINCT chunk_id) FROM public.casper_manual_embeddings) AS unique_embedding_chunk_ids,
 (SELECT count(*) FROM public.casper_manual_embeddings e LEFT JOIN public.casper_manual_chunks c USING(chunk_id) WHERE c.chunk_id IS NULL) AS embeddings_without_chunk,
 (SELECT count(*) FROM public.casper_manual_chunks c LEFT JOIN public.casper_manual_embeddings e USING(chunk_id) WHERE e.chunk_id IS NULL) AS chunks_without_embedding;

SELECT embedding_model, embedding_version, embedding_dimension,
       vector_dims(embedding) AS actual_vector_dimension, count(*) AS row_count
FROM public.casper_manual_embeddings
GROUP BY embedding_model, embedding_version, embedding_dimension, vector_dims(embedding)
ORDER BY embedding_model, embedding_version, embedding_dimension, actual_vector_dimension;
