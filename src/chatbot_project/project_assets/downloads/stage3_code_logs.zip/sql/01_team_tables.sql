-- Actual team database DDL supplied by the user. No DROP commands.
CREATE TABLE public.casper_manual_chunks (
    chunk_id text NOT NULL,
    document_name text NULL,
    chapter text NULL,
    "section" text NULL,
    subsection text NULL,
    source_title text NULL,
    page_start int4 NULL,
    page_end int4 NULL,
    chunk_index int4 NULL,
    chunk_text text NOT NULL,
    token_count int4 NULL,
    CONSTRAINT casper_manual_chunks_pkey PRIMARY KEY (chunk_id)
);

CREATE TABLE public.casper_manual_embeddings (
    chunk_id text NOT NULL,
    embedding_model text NOT NULL,
    embedding_version text NOT NULL,
    embedding_dimension int4 NOT NULL,
    embedding public.vector NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    CONSTRAINT casper_manual_embeddings_pkey PRIMARY KEY (chunk_id)
);
ALTER TABLE public.casper_manual_embeddings
    ADD CONSTRAINT casper_manual_embeddings_chunk_id_fkey
    FOREIGN KEY (chunk_id) REFERENCES public.casper_manual_chunks(chunk_id)
    ON DELETE CASCADE;
