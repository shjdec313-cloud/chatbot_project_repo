# CASPER 3단계 · RAG 파이프라인 코드와 적재 기록

압축을 풀고 index.html을 열어 1~6 순서대로 읽으세요. 외부 참고 없이 안내·코드·로그를 확인할 수 있습니다.

## 제출 범위
- CSV → 임베딩 → 개인 DB 적재 → 팀 DB 이관 → 앱 연결 → 검색과 답변
- 기존 실행 로그와 대화의 사용자 확인, 새로 수행한 로컬 파일 확인을 구분합니다.
- 이관 과정의 오류·해결 내역은 요청에 따라 제외했습니다.

## 실제 자료
- 1,874행 CSV, 개인·팀 데이터 덤프, 노트북 적재 stdout
- 사용자가 실제 팀 DB에서 제공한 두 테이블과 검색 함수 DDL
- 현재 로컬 앱 코드 참고 사본

## 코드 정리
- code/index_csv.py: 기본은 CSV 확인만; --write 지정 시 실제 임베딩·DB upsert·로그 기록
- code/rag.py: 기존 RAG 흐름 유지; .env, Streamlit Secrets, 환경변수를 합친 동일 설정으로 검사·연결
- code/app2.py: 현재 로컬 앱 사본
- sql/: 실제 팀 DB 구조, 검색 함수, 읽기 전용 확인 쿼리
- code/restore_team.ps1: 기존 팀 테이블이 비어 있는 재현 환경에서 제공 덤프 복원

## 실행
Python 3.12 이상. 프로젝트 기본 답변 모델은 gpt-6-luna입니다. API 계정에서 사용 가능한 모델을 OPENAI_MODEL에 지정하세요.
아래 명령은 안내이며 이번에 실행하지 않았습니다.

```powershell
python -m pip install -r code/requirements.txt
python -m streamlit run code/app2.py
python code/index_csv.py --target personal
# 실제 생성/적재 시에만:
python code/index_csv.py --target personal --write
```

로컬은 code/.env.example을 code/.env로 복사해 값을 입력합니다.
Cloud는 code/secrets.example.toml의 항목을 App settings의 Secrets에 등록합니다.
설정 우선순위: .env < Streamlit Secrets < 환경변수. 실제 키는 제출 폴더에 포함하지 않았습니다.

## 기록의 한계
- 이전 노트북의 개인 DB 적재 배치는 1874/1874까지 출력되어 있습니다. 일부 한글 출력은 원본에서 깨져 있습니다.
- 당시 입력 파일 해시와 시작·종료 시각은 제공되지 않았습니다. 기존 저장 벡터가 최종 CSV에서 다시 생성한 벡터와 동일한지는 재실행하지 않았습니다.
- 덤프와 CSV의 청크 ID·본문 일치, 개인/팀 덤프의 데이터 내용 일치, 실제 저장 벡터의 차원은 로컬 파일을 읽어 확인했습니다.
- 팀 복원 완료와 확인 결과는 대화에서 사용자가 보고한 내용입니다. 전체 psql 출력이나 Cloud 성공 로그는 제공되지 않았습니다.
- DB 접속, 새 적재, 모델/API 호출, 앱 실행 및 브라우저 화면 검토를 이번 제작에서 수행하지 않았습니다.
- 검색 품질 평가와 정답 라벨은 4단계 범위입니다.

노트북 참고 사본은 자격증명 형태의 문자열을 제거했습니다. 실제 값은 .env 또는 Secrets로 별도 설정하세요.
폴더를 통째로 보관해야 안내 링크가 유지됩니다.
